package com.spiderBookStall.CustomerController;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.security.Principal;

@Controller
public class CustomerBookController
{
    @RequestMapping(value = "buyBook/{bookid}",method = RequestMethod.GET)
    public String buyBook(@PathVariable("bookid") String bookID, Principal principal, Model model)
    {
        model.addAttribute("bookid",bookID);

        return "checkOutPage";
    }
}
