package com.spiderBookStall.CustomerController;

import com.spiderBookStall.CustomerDto.CustomerDetail;
import com.spiderBookStall.CustomerService.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ControllerAdvice;

import java.security.Principal;

@ControllerAdvice
public class abstractController {
    @Autowired
    private CustomerService customerService;

    public CustomerDetail getAllData(Principal principal)
    {
        CustomerDetail customerDetail = customerService.getProfile(principal.getName());
        return customerDetail;

    }
}
