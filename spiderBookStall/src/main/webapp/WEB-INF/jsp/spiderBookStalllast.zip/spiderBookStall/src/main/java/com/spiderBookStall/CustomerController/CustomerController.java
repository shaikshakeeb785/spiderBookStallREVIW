package com.spiderBookStall.CustomerController;

import com.spiderBookStall.CustomValidator.CustomerRegistrationValidator;
import com.spiderBookStall.CustomerDto.CustomerDetail;
import com.spiderBookStall.CustomerDto.Order;
import com.spiderBookStall.CustomerService.CustomerService;
import com.spiderBookStall.RestService.BookRestApiService;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Random;

@Controller
public class CustomerController {
    private static final Logger logger = LogManager.getLogger(CustomerController.class);

    @Autowired
    private CustomerService customerService;
    @Autowired
    @Qualifier("customerRegistrationValidator")
    private CustomerRegistrationValidator customerRegistrationValidator;
    @Autowired
    @Qualifier("BookRestApiService")
    private BookRestApiService bookRestApiService;

    @RequestMapping("/Register")
    public String customerRegistration(Model model) {

        BasicConfigurator.configure();
        logger.info("Inside CustomerRegistration Method");
        model.addAttribute("registerObject", new CustomerDetail());

        return "customerRegistrationPage";
    }

    @RequestMapping(value = "/saveRegister", method = RequestMethod.POST)
    public String saveRegisterCustomer(@ModelAttribute("registerObject") CustomerDetail customerRegistration, BindingResult result, Model model) throws SQLIntegrityConstraintViolationException {
        logger.info("Inside saveRegisterCustomer Method");
        int value=customerService.duplicateEntry(customerRegistration.getEmail());
        if(value>0)
        {
            result.rejectValue("email","email.errors","Duplicate Entry Is Not Allowed Here");

        }
        customerRegistrationValidator.validate(customerRegistration, result);
        if (result.hasErrors())
        {
            return "customerRegistrationPage";
        } else
         {
            try
            {
                int result1 = customerService.saveRegisteredCustomer(customerRegistration);
                if (result1 >= 1)
                {
                    model.addAttribute("customerSaved","CUSTOMER REGISTER SUCCESSFULLY");
                    return "redirect:/login";
                }
            } catch (EmptyResultDataAccessException e)
            {
                logger.error("ERROR IS:"+e.getMessage());
                model.addAttribute("error1","REGISTRATION FAILED");
            }
        }
            return "error";

    }
    @RequestMapping(value = "/profile/{emailId}", method = RequestMethod.GET)
    public String getProfile(@PathVariable("emailId") String emailId, Model model) {

        logger.info("Inside getRecordById Method");
        try{
            CustomerDetail customerDetail = customerService.getProfile(emailId);
            model.addAttribute("customerDetail", customerDetail);
        } catch (EmptyResultDataAccessException e) {
            model.addAttribute("error","Profile is NotFound For searched Id");
            e.printStackTrace();
        }


        return "profilePage";
    }

    @RequestMapping(value = "/buyBook/{bookID}", method = RequestMethod.GET)
    public String buyBook(@PathVariable("bookID") String bookID, Principal principal, Model model) {

        logger.info("Inside buyBook method ");
      try{

          CustomerDetail customerDetail = customerService.getRecordById(principal.getName());
          if(customerDetail!=null)
          {
              model.addAttribute("customerDetail", customerDetail);
              model.addAttribute("bookId", bookID);
              return "checkOutPage";
          }
      } catch (Exception e) {
          e.printStackTrace();
      }
          return "error";

    }

    @RequestMapping("/orderPlaced/{bookId}")
    public String oderPlaced(@ModelAttribute("order") Order order1, @PathVariable("bookId") String bookId, Principal principal, Model model) {

        logger.info("Inside BuyBook Method ");
        order1.setProductID(bookId);
        Random random = new Random();
        int orderId = random.nextInt();
        String UserId = principal.getName();
        order1.setUserId(UserId);
        order1.setOderId(orderId);
        model.addAttribute("orderId", orderId);
        model.addAttribute("bookObject1", bookRestApiService.getBookById(bookId));
        int result = customerService.saveOrder(order1);
        if (result >= 1) {
            return "orderPlacedPage";
        }
        return null;
    }

    @RequestMapping("/editCustomer/{email}")
    public String updateProfile(@PathVariable("email") String Email, Model model) {
        logger.info("Inside UpdateProfile Method ");
        try{
            CustomerDetail customerObject = customerService.getProfile(Email);
            model.addAttribute("customerObject",customerObject);
            return "updatePage";
        }catch (IllegalStateException e)
        {
            logger.error("ERROR IS:"+e.getMessage());
            e.printStackTrace();
            model.addAttribute("mes5",e.getMessage());
        }
        return "error";
    }

    @RequestMapping(value = "/saveUpdate", method = RequestMethod.POST)
    public String updatedProfile(@ModelAttribute("customerObject") CustomerDetail detail) {
        int result = customerService.updateProfile(detail);
        if (result >= 1) {
            return "saveUpdatePage";
        }
        return "error";
    }

}
