package com.spiderBookStall.CustomerService;

import com.spiderBookStall.CustomerDto.CustomerDetail;
import com.spiderBookStall.CustomerDto.Order;
import org.springframework.dao.EmptyResultDataAccessException;

import java.sql.SQLIntegrityConstraintViolationException;


public interface CustomerService {
    /**
     * saveRegisteredCustomer method is used to saved the data into the database and return no of record is effected
     * @return no of record is effected
     */
    public int saveRegisteredCustomer(CustomerDetail customerRegistration)throws EmptyResultDataAccessException;

    /**
     * @param EmailId get record by using Email id from the database
     * @return CustomerDetail
     */
    public CustomerDetail getRecordById(String EmailId);

    /**
     * updating customerProfile by using email
     *
     * @param detail customer updated detail
     * @return no of record is effected
     */
    public int updateProfile(CustomerDetail detail)throws IllegalStateException;

    /**
     * @param order it is object of ORDER which is saved into the database
     * @return no of record is effected;
     */
    public int saveOrder(Order order);

    /**
     * @param EmailId using id getting customerProfile detail
     * @return customerProfile
     */
    public CustomerDetail getProfile(String EmailId)throws EmptyResultDataAccessException,IllegalStateException;

    /**if customer adding duplicating entry again in database then it will not store in database
     * @param email
     * @return
     */
    public int duplicateEntry(String  email)throws SQLIntegrityConstraintViolationException;


}
