package com.spiderBookStall.CustomerController;

import com.spiderBookStall.CustomerService.CustomerService;
import com.spiderBookStall.RestService.BookRestApiService;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.security.Principal;

@Controller
public class HomeController {
    private static final Logger logger = LogManager.getLogger(CustomerController.class);
    @Autowired
    private BookRestApiService bookRestApiService;
    @Autowired
    private CustomerService customerService;

    @RequestMapping(value = "/homePage", method = RequestMethod.GET)
    public String home(Model model, Principal principal) {

        logger.info("Inside Home Method");
        BasicConfigurator.configure();
        if (principal != null) {
            model.addAttribute("objCustomer", customerService.getRecordById(principal.getName()));
        }
        model.addAttribute("restObject", bookRestApiService.getALLBookRestData());

        return "homePage";
    }

    @RequestMapping(value = "/contact", method = RequestMethod.GET)
    public String aboutUs() {
        logger.info("Inside AboutUs Method");
        return "aboutPage";
    }

    @RequestMapping("/login")
    public String login(@RequestParam(value = "error", required = false) String error,
                        @RequestParam(value = "logout", required = false) String logout,
                        Model model) {
        logger.info("Inside Login Method");
        if (error != null) {
            model.addAttribute("error", "INVALID USERNAME OR PASSWORD!");
        }

        if (logout != null) {
            model.addAttribute("msg", "YOU HAVE LOGGED OUT SUCCESSFULLY.");
        }
        return "loginPage";
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public String logout(Model model) {

        logger.info("inside logout method");
        model.addAttribute("title", "Logged out page");

        return "logoutPage";
    }
    @RequestMapping(value = "/denied", method = RequestMethod.POST)
    public String denied() {
        System.out.println("under denied");
        return "deniedPage";
    }
    @RequestMapping(value = "/404", method = RequestMethod.GET)
    public ModelAndView denied(Principal user) {

        ModelAndView model = new ModelAndView();
        if (user != null) {
            model.addObject("msg", "Hi " + user.getName()+user.toString()
                    + ", You can not access this page!");
        } else {
            model.addObject("msg",
                    "You can not access this page!");
        }

        model.setViewName("notFoundPage");
        return model;
    }


}


