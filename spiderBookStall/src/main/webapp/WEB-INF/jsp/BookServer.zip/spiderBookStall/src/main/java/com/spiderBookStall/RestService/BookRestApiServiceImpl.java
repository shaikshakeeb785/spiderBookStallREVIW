package com.spiderBookStall.RestService;

import com.spiderBookStall.CustomerController.CustomerController;
import com.spiderBookStall.CustomerDto.Book;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * implementation for {@link BookRestApiService}
 */
public class BookRestApiServiceImpl implements BookRestApiService {

    private static final Logger logger = LogManager.getLogger(CustomerController.class);
    private RestTemplate restTemplate;

    @Override
    public List<Book> getALLBookRestData() {

        BasicConfigurator.configure();
        logger.info("Inside getALLBookRestData Method which written All Server Side Book in Json Form");
        String url = "http://localhost:8081/SpiderBookStore_war_exploded/getAllBooksJson";
        try {
            ResponseEntity<Book[]> responseEntity = restTemplate.getForEntity(url, Book[].class);
            if (responseEntity.getBody() != null) {
                return Arrays.asList(responseEntity.getBody());
            }
        } catch (RestClientException e) {
            logger.error("Exception while rest data:" + e.getMessage());
            e.printStackTrace();
        }
        return Collections.emptyList();
    }

    @Override
    public Book getBookById(String bookId) {
        Book book = null;
        logger.info("Inside getBookById Method which written Particular Book Based On BookId/BookName From server");
        String url = "http://localhost:8081/SpiderBookStore_war_exploded/getByIdJsonData?bookId=" + bookId;
        try {
            book = restTemplate.getForObject(url, Book.class);
            return book;
        } catch (RestClientException e) {
            logger.error("Exception while rest data" + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public int saveClientBook(Book book) {
        int result = 0;
        logger.info("Inside saveClientBook Method Which Add The SellerBook To The Server");
        String url = "http://localhost:8081/SpiderBookStore_war_exploded/clientBookObject";
        try {
            result = getRestTemplate().postForObject(url, book, Integer.class);
            logger.info("result" + result);
            return result;
        } catch (RestClientException e) {
            logger.error("Exception while rest data" + e.getMessage());
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public List<Book> getAllSellerBook(String sellerName) {

        logger.info("Inside getAllSellerBook Method Which Return Seller Book Which Add To Server Based On SellerName");
        String url = "http://localhost:8081/SpiderBookStore_war_exploded/convertClientBookToJsonBySellerName/" + sellerName;
        try {
            ResponseEntity<Book[]> responseEntity = restTemplate.getForEntity(url, Book[].class);
            System.out.println(responseEntity.toString() + "return book detail");
            if (responseEntity.getBody() != null) {
                return Arrays.asList(responseEntity.getBody());
            }
        } catch (RestClientException e) {
            logger.error("Exception while rest data" + e.getMessage());
            e.printStackTrace();
        }
        return Collections.emptyList();
    }

    @Override
    public int deleteSellerBook(String bookId) {
        Integer result = 0;
        logger.info("Inside deleteSellerBook Method Which deleted Seller Book Based on BookId");
        String url = "http://localhost:8081/SpiderBookStore_war_exploded/deleteClientBook/" + bookId;
        try {
            result = restTemplate.getForObject(url, Integer.class);
            return result;
        } catch (RestClientException e) {
            logger.error("Exception while rest data" + e.getMessage());
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public int updateClientBook(Book book) throws IllegalStateException {
        int result = 0;
        logger.info("Inside updateClientBook Method Which UpdateClientBook In server");
        String url = "http://localhost:8081/SpiderBookStore_war_exploded/updateClientBook";
        try {
            ResponseEntity<Integer> entity = getRestTemplate().postForEntity(url, book, Integer.class);
            logger.info("no of record is effected" + entity.getBody());
            result = entity.getBody();
            return result;
        } catch (RestClientException e) {
            logger.error("Exception while rest data" + e.getMessage());
            e.printStackTrace();
        }
        return result;
    }

    public RestTemplate getRestTemplate() {
        return restTemplate;
    }

    @Required
    public void setRestTemplate(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }
}
