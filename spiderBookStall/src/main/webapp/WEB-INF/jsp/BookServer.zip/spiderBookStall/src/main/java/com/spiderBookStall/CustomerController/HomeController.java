package com.spiderBookStall.CustomerController;

import com.spiderBookStall.CustomValidator.CustomerRegistrationValidator;
import com.spiderBookStall.CustomerDto.CustomerDetail;
import com.spiderBookStall.CustomerService.CustomerService;
import com.spiderBookStall.RestService.BookRestApiService;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@Controller
public class HomeController {
    private static final Logger logger = LogManager.getLogger(CustomerController.class);
    @Autowired
    private BookRestApiService bookRestApiService;
    @Autowired
    private CustomerService customerService;
    @Autowired
    @Qualifier("customerRegistrationValidator")
    private CustomerRegistrationValidator customerRegistrationValidator;

    @RequestMapping(value = "/homePage", method = RequestMethod.GET)
    public String home(Model model, Principal principal) {

        logger.info("Inside Home Method");
        BasicConfigurator.configure();
        if (principal != null) {
            model.addAttribute("objCustomer", customerService.getRecordById(principal.getName()));
        }
        model.addAttribute("restObject", bookRestApiService.getALLBookRestData());

        return "homePage";
    }
    @RequestMapping(value = "/contact", method = RequestMethod.GET)
    public String aboutUs() {
        logger.info("Inside AboutUs Method");

        return "aboutPage";
    }
    @RequestMapping("/login")
    public String login(@RequestParam(value = "error", required = false) String error,
                        @RequestParam(value = "logout", required = false) String logout,
                        Model model) {
        logger.info("Inside Login Method");
        if (error != null) {
            model.addAttribute("error", "INVALID USERNAME OR PASSWORD!");
        }
        if (logout != null) {
            model.addAttribute("msg", "YOU HAVE LOGGED OUT SUCCESSFULLY.");
        }

        return "loginPage";
    }
    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public String logout(Model model) {

        logger.info("inside logout method");
        model.addAttribute("title", "Logged out page");

        return "logoutPage";
    }
    @RequestMapping("/Register")
    public String customerRegistration(Model model) {

        BasicConfigurator.configure();
        logger.info("Inside CustomerRegistration Method");
        model.addAttribute("registerObject", new CustomerDetail());

        return "customerRegistrationPage";
    }
    @RequestMapping(value = "/saveRegister", method = RequestMethod.POST)
    public String saveRegisterCustomer(@ModelAttribute("registerObject") CustomerDetail customerRegistration, BindingResult result, Model model) {

        logger.info("Inside saveRegisterCustomer Method");
        int value = customerService.duplicateEntry(customerRegistration.getEmail());
        if (value > 0) {
            result.rejectValue("email", "email.errors", "Duplicate Entry Is Not Allowed Here");
        }
        customerRegistrationValidator.validate(customerRegistration, result);
        if (result.hasErrors()) {

            return "customerRegistrationPage";
        } else {
            int result1 = customerService.saveRegisteredCustomer(customerRegistration);
            if (result1 >= 1) {
                return "redirect:/login";
            } else {
                model.addAttribute("error1", "REGISTRATION FAILED");

                return "error";
            }
        }
    }
    @RequestMapping(value = "/denied", method = RequestMethod.POST)
    public String denied() {
        System.out.println("under denied");
        return "deniedPage";
    }


}


