package com.spiderBookStall.RestService;

import com.spiderBookStall.CustomerDto.Book;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * implementation for {@link BookRestApiService}
 */
public class BookRestApiServiceImpl implements BookRestApiService {
    private RestTemplate restTemplate;

    @Override
    public List<Book> getALLBookRestData() {
        String url= "http://localhost:8081/SpiderBookStore_war_exploded/getAllBooksjson";
        ResponseEntity<Book[]> responseEntity= restTemplate.getForEntity(url,Book[].class);
        if(responseEntity.getBody()!=null)
        {
            return  Arrays.asList(responseEntity.getBody());
        }
        return  Collections.emptyList();
    }

    @Override
    public Book getBookById(String bookId) {
        String url="http://localhost:8081/SpiderBookStore_war_exploded/getByIdjsondata?bookId="+bookId;
       Book book= restTemplate.getForObject(url,Book.class);
        return book;
    }
    @Override
    public  Book sellerPortal(Book book)
    {
        String url="http://localhost:8081/SpiderBookStore_war_exploded/clientBookObject";
        Book book1=getRestTemplate().postForObject(url,book,Book.class);
        System.out.println(book1+"**********************");
        return book1;
    }

    public RestTemplate getRestTemplate() {
        return restTemplate;
    }
    @Required
    public void setRestTemplate(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }
}
