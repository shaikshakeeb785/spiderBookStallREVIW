package com.spiderBookStall.CustomerController;

import com.spiderBookStall.CustomValidator.CustomerRegistrationValidator;
import com.spiderBookStall.CustomerDto.CustomerDetail;
import com.spiderBookStall.CustomerDto.Order;
import com.spiderBookStall.CustomerService.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpSession;
import java.security.Principal;
import java.util.Random;

@Controller
public class CustomerController
{
    @Autowired
    private CustomerService customerService;
    @Autowired
    private CustomerRegistrationValidator customerRegistrationValidator;

    @RequestMapping("/Register")
    public String customerRegistration( Model model)
    {
        model.addAttribute("registerObject", new CustomerDetail());
        return "customerRegistrationPage";
    }

    @RequestMapping(value = "/saveRegister",method = RequestMethod.POST)
    public String saveRegisterdCustomer(@ModelAttribute("registerObject") CustomerDetail customerRegistration, BindingResult result,HttpSession httpSession ,Model model)
    {

        customerRegistrationValidator.validate(customerRegistration,result);
        int i=customerService.saveRegisterdCustomer(customerRegistration,httpSession);
       if(result.hasErrors())
       {
           return "customerRegistrationPage";
       }
        else if(i>=1)
        {
            return "redirect:/homePage";

        }else {
           return "error";
       }

    }
    @RequestMapping("/profile/{emailId}")
    public  String getRecordById(@PathVariable("emailId") String emailId,Model model)
    {
        CustomerDetail customerDetail=customerService.getProfile(emailId);
        model.addAttribute("cutomerDetail",customerDetail);
        return "profilePage";
    }

    @RequestMapping(value = "buyBook/{bookid}", method = RequestMethod.GET)
    public String buyBook(@PathVariable("bookid") String bookID, Principal principal, Model model) {

        CustomerDetail customerDetail=customerService.getRecordById(principal.getName());
        model.addAttribute("customerDetail", customerDetail);
        model.addAttribute("bookid", bookID);

        return "checkOutPage";
    }
    @RequestMapping("/orderPlaced/{bookid}")
    public String oderPlaced(@ModelAttribute("order") Order order1, @PathVariable("bookid") String bookid,Principal principal,Model model)
    {
        order1.setProductID(bookid);
        Random random=new Random();
        int orderId=random.nextInt();
        String UserId=principal.getName();
        order1.setUserId(UserId);
        order1.setOderId(orderId);
        model.addAttribute("orderId",orderId);
        int result=customerService.saveOrder(order1);
        if(result>=1)
        {
            return "orderPlacedPage";
        }
        return null;
    }
     @RequestMapping("/sellerportal")
    public RedirectView sellerPortalAddbook()
    {
       RedirectView redirectView= customerService.sellerPortal();
        return redirectView;
    }


}
